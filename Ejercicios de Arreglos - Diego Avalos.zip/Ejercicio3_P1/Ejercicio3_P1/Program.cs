﻿using System;

class Program
{
    static void Main()
    {
        double[,] calif = new double[5, 4];

        for (int i = 0; i < 5; i++)
        {
            double suma = 0;
            Console.WriteLine($"\nIngrese las calificaciones del alumno {i + 1}:");

            for (int j = 0; j < 3; j++)
            {
                Console.Write($"Parcial {j + 1}: ");
                while (!double.TryParse(Console.ReadLine(), out calif[i, j]) || calif[i, j] < 0 || calif[i, j] > 10)
                {
                    Console.Write("Entrada inválida. Ingrese una calificación entre 0 y 10: ");
                }
                suma += calif[i, j];
            }

            calif[i, 3] = suma / 3;
        }

        Console.WriteLine("\nCalificaciones y Promedios:");
        Console.WriteLine("Alumno\tParcial 1\tParcial 2\tParcial 3\tPromedio");

        for (int i = 0; i < 5; i++)
        {
            Console.Write($"{i + 1}\t");
            for (int j = 0; j < 4; j++)
            {
                Console.Write($"{calif[i, j]:F2}\t\t");
            }
            Console.WriteLine();
        }
    }
}