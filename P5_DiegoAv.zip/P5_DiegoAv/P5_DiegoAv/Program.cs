﻿using System;

namespace EjemploArbol
{
    internal class Nodo
    {
        public int Info; //Aqui se guarda el valor del nodo
        public Nodo Izq, Der; //Izq - Hijo del lado izquierdo y Der - Hijo del lado derecho
        public Nodo(int info) { Info = info; Izq = Der = null; }
    }

    internal class ArbolBinario
    {
        Nodo raiz;

        public void Insertar(int info) //Agregar nodos
        {
            Nodo nuevo = new Nodo(info), reco = raiz, anterior = null;
            while (reco != null)
            {
                anterior = reco;
                reco = info < reco.Info ? reco.Izq : reco.Der;
            }
            if (anterior == null) raiz = nuevo;
            else if (info < anterior.Info) anterior.Izq = nuevo;
            else anterior.Der = nuevo;
        }

        private void Recorrer(Nodo nodo, int tipo) //Método recursivo que permite recorrer el árbol
        {
            if (nodo != null)
            {
                if (tipo == 1) Console.Write(nodo.Info + " ");
                Recorrer(nodo.Izq, tipo);
                if (tipo == 2) Console.Write(nodo.Info + " ");
                Recorrer(nodo.Der, tipo);
                if (tipo == 3) Console.Write(nodo.Info + " ");
            }
        }

        public void InOrden() { Recorrer(raiz, 2); Console.WriteLine(); }
        public void PreOrden() { Recorrer(raiz, 1); Console.WriteLine(); }
        public void PostOrden() { Recorrer(raiz, 3); Console.WriteLine(); }

        public bool Buscar(int criterio) //Para buscar un nodo comparando criterios
        {
            Nodo reco = raiz;
            while (reco != null && reco.Info != criterio)
                reco = criterio < reco.Info ? reco.Izq : reco.Der;
            return reco != null;
        }

        public void Eliminar(int info) //Busca y elimina nodos
        {
            raiz = EliminarNodo(raiz, info);
        }

        private Nodo EliminarNodo(Nodo nodo, int info)
        {
            if (nodo == null) return nodo;
            if (info < nodo.Info) nodo.Izq = EliminarNodo(nodo.Izq, info);
            else if (info > nodo.Info) nodo.Der = EliminarNodo(nodo.Der, info);
            else
            {
                if (nodo.Izq == null) return nodo.Der;
                if (nodo.Der == null) return nodo.Izq;
                Nodo sucesor = MinimoValor(nodo.Der);
                nodo.Info = sucesor.Info;
                nodo.Der = EliminarNodo(nodo.Der, sucesor.Info);
            }
            return nodo;
        }

        private Nodo MinimoValor(Nodo nodo)
        {
            while (nodo.Izq != null) nodo = nodo.Izq;
            return nodo;
        }
    }

    class Program
    {
        static void Main()
        {
            ArbolBinario arbol = new ArbolBinario();
            int opcion, valor = 0;

            do
            {
                Console.WriteLine("\n1. Insertar 2. Buscar 3. Inorden 4. Preorden 5. Postorden 6. Eliminar 7. Salir");
                opcion = int.Parse(Console.ReadLine());
                if (opcion == 7) break;
                if (opcion == 1 || opcion == 2 || opcion == 6)
                {
                    Console.Write("Valor: ");
                    valor = int.Parse(Console.ReadLine());
                }
                switch (opcion)
                {
                    case 1: arbol.Insertar(valor); break;
                    case 2: Console.WriteLine(arbol.Buscar(valor) ? "Encontrado" : "No encontrado"); break;
                    case 3: arbol.InOrden(); break;
                    case 4: arbol.PreOrden(); break;
                    case 5: arbol.PostOrden(); break;
                    case 6: arbol.Eliminar(valor); break;
                }
            } while (true);
        }
    }
}
