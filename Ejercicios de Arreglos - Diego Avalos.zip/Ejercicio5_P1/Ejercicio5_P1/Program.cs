﻿using System;

class Program
{
    static void Main()
    {
        double[] ventas = new double[100];
        double TIngresos = 0;

        Console.WriteLine("Ingrese el monto de ventas de cada cliente:");

        for (int i = 0; i < 100; i++)
        {
            Console.Write($"Cliente {i + 1}: $");
            while (!double.TryParse(Console.ReadLine(), out ventas[i]) || ventas[i] < 0)
            {
                Console.Write("Entrada inválida. Ingrese un monto válido (mayor o igual a 0): $");
            }

            TIngresos += ventas[i];
        }

        Console.WriteLine($"\nTotal de ingresos del supermercado: ${TIngresos:F2}");
    }
}
