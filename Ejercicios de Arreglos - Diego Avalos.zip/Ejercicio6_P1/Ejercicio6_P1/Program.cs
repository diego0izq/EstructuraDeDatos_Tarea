﻿using System;

class Program
{
    static void Main()
    {
        int[] num1 = new int[20];
        int par = 0, impar = 0;

        Console.WriteLine("Ingrese 20 números enteros:");

        for (int i = 0; i < 20; i++)
        {
            Console.Write($"Número {i + 1}: ");
            while (!int.TryParse(Console.ReadLine(), out num1[i]))
            {
                Console.Write("Entrada inválida. Ingrese un número entero: ");
            }
        }

        foreach (int num in num1)
        {
            if (num % 2 == 0)
                par++;
            else
                impar++;
        }

        // Mostrar resultados
        Console.WriteLine($"\nCantidad de números pares: {par}");
        Console.WriteLine($"Cantidad de números impares: {impar}");
    }
}
