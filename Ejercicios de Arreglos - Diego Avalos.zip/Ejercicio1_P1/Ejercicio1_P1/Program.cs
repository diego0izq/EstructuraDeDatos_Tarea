﻿using System;

class Program
{
    static void Main()
    {
        double[] calificaciones = new double[6];

        for (int i = 0; i < 5; i++)
        {
            Console.Write($"Ingrese la calificación del parcial {i + 1}: ");
            while (!double.TryParse(Console.ReadLine(), out calificaciones[i]) || calificaciones[i] < 0 || calificaciones[i] > 10)
            {
                Console.Write("Entrada inválida. Ingrese una calificación entre 0 y 10: ");
            }
        }

        double suma = 0;
        for (int i = 0; i < 5; i++)
        {
            suma += calificaciones[i];
        }
        calificaciones[5] = suma / 5;

        Console.WriteLine("\nCalificaciones ingresadas:");
        for (int i = 0; i < 5; i++)
        {
            Console.WriteLine($"Parcial {i + 1}: {calificaciones[i]:F2}");
        }

        Console.WriteLine($"\nPromedio final: {calificaciones[5]:F2}");
    }
}