﻿using System;

class Program
{
    static void Main()
    {
        double[,] prom = new double[10, 3];

        Console.WriteLine("Ingrese los promedios del Grupo A:");
        CapProm(prom, 0);

        Console.WriteLine("\nIngrese los promedios del Grupo B:");
        CapProm(prom, 1);

        for (int i = 0; i < 10; i++)
        {
            prom[i, 2] = Math.Max(prom[i, 0], prom[i, 1]);
        }

        Console.WriteLine("\nResultados:");
        Console.WriteLine("Alumno\tGrupo A\tGrupo B\tMayor Promedio");

        for (int i = 0; i < 10; i++)
        {
            Console.Write($"{i + 1}\t");
            for (int j = 0; j < 3; j++)
            {
                Console.Write($"{prom[i, j]:F2}\t");
            }
            Console.WriteLine();
        }
    }

    static void CapProm(double[,] matriz, int columna)
    {
        for (int i = 0; i < 10; i++)
        {
            Console.Write($"Ingrese el promedio del alumno {i + 1}: ");
            while (!double.TryParse(Console.ReadLine(), out matriz[i, columna]) || matriz[i, columna] < 0 || matriz[i, columna] > 10)
            {
                Console.Write("Entrada inválida. Ingrese un promedio entre 0 y 10: ");
            }
        }
    }
}
