﻿using System;
using System.Collections.Generic;

class Grafo
{
    private Dictionary<string, List<string>> adjList;
    private bool esDirigido;

    public Grafo(bool dirigido)
    {
        adjList = new Dictionary<string, List<string>>();
        esDirigido = dirigido;
    }

    public void AgregarNodo(string nodo)
    {
        if (!adjList.ContainsKey(nodo))
            adjList[nodo] = new List<string>();
    }

    public void AgregarArista(string origen, string destino)
    {
        if (!adjList.ContainsKey(origen))
            AgregarNodo(origen);
        if (!adjList.ContainsKey(destino))
            AgregarNodo(destino);

        adjList[origen].Add(destino);
        if (!esDirigido)
            adjList[destino].Add(origen);
    }

    public void MostrarGrafo()
    {
        Console.WriteLine("\nRepresentación del Grafo:");
        foreach (var nodo in adjList)
        {
            Console.Write(nodo.Key + " -> ");
            foreach (var vecino in nodo.Value)
            {
                Console.Write(vecino + " ");
            }
            Console.WriteLine();
        }
    }

    public void BFS(string inicio)
    {
        if (!adjList.ContainsKey(inicio))
        {
            Console.WriteLine("El nodo no existe en el grafo.");
            return;
        }

        Queue<string> cola = new Queue<string>();
        HashSet<string> visitados = new HashSet<string>();

        cola.Enqueue(inicio);
        visitados.Add(inicio);

        Console.Write("\nBFS desde " + inicio + ": ");
        while (cola.Count > 0)
        {
            string actual = cola.Dequeue();
            Console.Write(actual + " ");

            foreach (var vecino in adjList[actual])
            {
                if (!visitados.Contains(vecino))
                {
                    cola.Enqueue(vecino);
                    visitados.Add(vecino);
                }
            }
        }
        Console.WriteLine();
    }

    public void DFS(string inicio)
    {
        if (!adjList.ContainsKey(inicio))
        {
            Console.WriteLine("El nodo no existe en el grafo.");
            return;
        }

        HashSet<string> visitados = new HashSet<string>();
        Console.Write("\nDFS desde " + inicio + ": ");
        DFSRecursivo(inicio, visitados);
        Console.WriteLine();
    }

    private void DFSRecursivo(string nodo, HashSet<string> visitados)
    {
        if (visitados.Contains(nodo))
            return;

        Console.Write(nodo + " ");
        visitados.Add(nodo);

        foreach (var vecino in adjList[nodo])
        {
            DFSRecursivo(vecino, visitados);
        }
    }
}

class Program
{
    static void Main()
    {
        Console.Write("¿El grafo es dirigido? (s/n): ");
        bool dirigido = Console.ReadLine().ToLower() == "s";

        Grafo grafo = new Grafo(dirigido);
        string opcion;

        do
        {
            Console.WriteLine("\n--- Menú del Grafo ---");
            Console.WriteLine("1. Agregar Nodo");
            Console.WriteLine("2. Agregar Arista");
            Console.WriteLine("3. Mostrar Grafo");
            Console.WriteLine("4. Recorrido BFS");
            Console.WriteLine("5. Recorrido DFS");
            Console.WriteLine("6. Salir");
            Console.Write("Elige una opción: ");
            opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":
                    Console.Write("Ingresa el nombre del nodo: ");
                    string nodo = Console.ReadLine();
                    grafo.AgregarNodo(nodo);
                    break;
                case "2":
                    Console.Write("Ingresa el nodo de origen: ");
                    string origen = Console.ReadLine();
                    Console.Write("Ingresa el nodo de destino: ");
                    string destino = Console.ReadLine();
                    grafo.AgregarArista(origen, destino);
                    break;
                case "3":
                    grafo.MostrarGrafo();
                    break;
                case "4":
                    Console.Write("Ingresa el nodo de inicio para BFS: ");
                    string inicioBFS = Console.ReadLine();
                    grafo.BFS(inicioBFS);
                    break;
                case "5":
                    Console.Write("Ingresa el nodo de inicio para DFS: ");
                    string inicioDFS = Console.ReadLine();
                    grafo.DFS(inicioDFS);
                    break;
                case "6":
                    Console.WriteLine("Saliendo...");
                    break;
                default:
                    Console.WriteLine("Opción inválida, intenta de nuevo.");
                    break;
            }
        } while (opcion != "6");
    }
}

