﻿using System;

class Program
{
    static void Main()
    {
        double[] grup1 = new double[5];
        double[] grup2 = new double[5];
        double[] mayorProm = new double[5];

        Console.WriteLine("Ingrese los promedios del primer grupo: ");
        CapPromedios(grup1);

        Console.WriteLine("\nIngrese los promedios del segundo grupo: ");
        CapPromedios(grup2);

        for (int i = 0; i < 5; i++)
        {
            mayorProm[i] = Math.Max(grup1[i], grup2[i]);
        }

        Console.WriteLine("\nPromedios más altos en cada posición:");
        for (int i = 0; i < 5; i++)
        {
            Console.WriteLine($"Posición {i + 1}: {mayorProm[i]:F2}");
        }
    }

    static void CapPromedios(double[] arreglo)
    {
        for (int i = 0; i < 5; i++)
        {
            Console.Write($"Ingrese el promedio del alumno {i + 1}: ");
            while (!double.TryParse(Console.ReadLine(), out arreglo[i]) || arreglo[i] < 0 || arreglo[i] > 10)
            {
                Console.Write("Entrada inválida. Ingrese un promedio entre 0 y 10: ");
            }
        }
    }
}