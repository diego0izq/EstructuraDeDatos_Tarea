﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        List<string> lista = new List<string>();
        bool salir = false; //A la variable salir se le da la opción de falso al inicializar

        while (!salir)
        {
            Console.WriteLine("1.- Agregar Elemento");
            Console.WriteLine("2.- Eliminar elemento");
            Console.WriteLine("3.- Mostrar lista");
            Console.WriteLine("4.- Salir");
            Console.Write("Selecciona una opción: "); //Opciones que puedes elegir
            string op = Console.ReadLine();

            switch (op)
            {
                case "1":
                    Console.Write("Ingresa el valor que deseas agregar: ");
                    string vAgregar = Console.ReadLine(); //A la variable valAgregar agregar el valor que se desea ingresar a la lista
                    lista.Add(vAgregar); //Valor agregado a la lista
                    Console.WriteLine($"'{vAgregar}' ha sido agregado.\n"); //Mostrar el valor que ha sido agregado a la lista
                break;

                case "2":
                    Console.Write("Ingresa el valor que deseas eliminar: "); 
                    string vEliminar = Console.ReadLine(); //Agregar a la variable valEliminar el valor que se desea eliminar de la lista
                    if (lista.Remove(vEliminar)) //Condición para saber si el valor que se desea eliminar existe o no
                    {
                        Console.WriteLine($"'{vEliminar}' ha sido eliminado.\n"); //En caso de que el valor si exista mostrar el valor que se elimino de la lista
                    }
                    else
                    {
                        Console.WriteLine($"'{vEliminar}' no se encontro ese valor.\n"); //En caso de que no exista el valor que se desea eliminar, hacerlo saber al usuario
                    }
                break;

                case "3":
                    Console.WriteLine("Lista: "); 
                    foreach (string Elemento in lista) //Correr la lista para posteriormente mostrarla
                    {
                        Console.WriteLine(Elemento); //Mostrar los elementos que han sido guardados en la lista
                    }
                    Console.WriteLine();
                break;

                case "4":
                    salir = true; //Salir del programa
                break;
            }
        }
    }
}
