﻿using System;

class Program
{
    static void Main()
    {
        int[] num = new int[20];   
        int[] cuadrado = new int[20]; 
        int[] cubo = new int[20]; 

        Console.WriteLine("Ingrese 20 números enteros:");

        for (int i = 0; i < 20; i++)
        {
            Console.Write($"Número {i + 1}: ");
            while (!int.TryParse(Console.ReadLine(), out num[i]))
            {
                Console.Write("Entrada inválida. Ingrese un número entero: ");
            }

            cuadrado[i] = num[i] * num[i];
            cubo[i] = num[i] * num[i] * num[i];
        }

        Console.WriteLine("\nResultados:");
        Console.WriteLine("Número\tCuadrado\tCubo");

        for (int i = 0; i < 20; i++)
        {
            Console.WriteLine($"{num[i]}\t{cuadrado}[i]}\t\t{cubo[i]}");
        }
    }
}